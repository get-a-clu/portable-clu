
/* Copyright Massachusetts Institute of Technology 1990,1991 */

/*						*/
/*						*/
/*		IMPLEMENTATION OF		*/
/*			version			*/
/*						*/

#include "pclu_err.h"
#include "pclu_sys.h"

int version = 7.0;

