#ifndef PCLUSERVER_H
#define PCLUSERVER_H

#define PCLUSERVERTMPFILE "/tmp/pcluserverstuff.%d"
#define SERVERTIMEOUT 4

#ifndef PCLUPROMPT
#define PCLUPROMPT "command(s): \n"
#endif

#define QUITECHOSTR "@@Quit\n"

#define PCLUMULTITIMEOUT 200
#define PCLUTIMEOUT 3600

/*****************************************************************************
  where is pclu? what are the commands that run it?  */
  
#ifndef CLUHOME
#define CLUHOME "/usr/local/lib/pclu"
#endif

#ifndef PCLUSERVERCOMMAND
#define PCLUSERVERCOMMAND "pcluserver"
#endif
#ifndef PCLUCOMMAND
#define PCLUCOMMAND "~/exe/pclu"
#endif
#ifndef CCLDCOMMAND
#define CCLDCOMMAND "cc"
#endif


/*****************************************************************************
  pclu library locations, what the libraries are, etc.  */
  
#ifndef PCLULIBDIR
#define PCLULIBDIR "~/code"
#endif
  
#ifndef PCLUDEBUGLIB
#define PCLUDEBUGLIB "-lpclu"
#endif
#ifndef PCLUOPTIMIZELIB
#define PCLUOPTIMIZELIB "-lpclu_opt"
#endif
#ifndef PCLUOTHERLIB
#define PCLUOTHERLIB "-lm"
#endif

#endif

