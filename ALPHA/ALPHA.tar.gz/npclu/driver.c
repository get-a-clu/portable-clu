#define _NO_PROTO
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#if !defined(__alpha)
#include <stdarg.h>
#endif
#include <signal.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include "pcluserver.h"
#include <varargs.h>


#ifndef CCVENEER
#define CCVENEER 0
#endif
#ifndef PCLUVENEER
#define PCLUVENEER 0
#endif
#ifndef pcluVENEER
#define pcluVENEER 0
#endif

#ifndef CC_ERROR_STRING
#define CC_ERROR_STRING "ccom: "
#define CC_ERROR_STRING_LEN 6
#endif
  
#if pcluVENEER + CCVENEER + PCLUVENEER == 0
#define CCVENEER 1
#elif pcluVENEER + CCVENEER + PCLUVENEER != 1
  Phooey Poopies! You can only define one veneer at a time.
#endif
  
  
#ifdef DEBUG
#define debug(x) Debug x
#else
#define debug(x)
#endif


volatile int servertimeout = 0;
char verbose = 0;		/* if !0, print out pclu commands before
				   executing them, and print out everything
				   pclu says back to us instead of filtering
				   it  */

char *cwd = NULL;		/* our current working directory  */
int cwdlen;			/* strlen(cwd)  */
char *program;			/* the name we were called as  */
char pcluservertmpfile[BUFSIZ]; /* our temporary file name  */
int errorcode = 0;		/* the error code to return when we exit */


enum action
{
  GUESS, LIBRARY, COMPILE, LINK, DUMPLIBRARY, OBJECT, EQUATE, SPECCHECK,
  COMPORSPEC, C_CRAP, ERROR, PCLU_CRAP, SORTOFCOMPILE
};

struct thingtodo {
  char *name;
  enum action action;
  struct thingtodo *next, *prev;
};


#if defined(__alpha)
void
fatal(va_alist)
va_dcl
{
  va_list al;
  char *string;
  va_start(al);
/*   fprintf(stderr, "%s: ", var_arg(al, char *)); */
  string = va_arg(al, char *);
  vfprintf(stderr, string, al);
  fputc('\n', stderr);
  va_end(al);
  exit(1);
}
#else
void
fatal(char *string, ...)
{
  va_list al;
  va_start(al, string);
  fprintf(stderr, "%s: ", program);
  vfprintf(stderr, string, al);
  fputc('\n', stderr);
  va_end(al);
  exit(1);
}
#endif


#if defined(__alpha)
void
warning(va_alist)
va_dcl
{
  va_list al;
  char *string;
  va_start(al);
  fprintf(stderr, "%s: warning: ", va_arg(al, char*));
  string = va_arg(al, char*);
  vfprintf(stderr, string, al);
  fputc('\n', stderr);
  va_end(al);
}

#else

void
warning(char *string, ...)
{
  va_list al;
  va_start(al, string);
  fprintf(stderr, "%s: warning: ", program);
  vfprintf(stderr, string, al);
  fputc('\n', stderr);
  va_end(al);
}

#endif


char *
mystrdup(char *inchar)
{
  char *x = malloc(strlen(inchar) + 1);
  strcpy(x, inchar);
  return x;
}


#ifdef DEBUG
void
Debug(char *string, ...)
{
  va_list al;
  va_start(al, string);
  fprintf(stderr, "[%s: ", program);
  vfprintf(stderr, string, al);
  fprintf(stderr, "] ");
  va_end(al);
}
#endif


void
usage(int help)
{
  
#if CCVENEER
  fprintf(stderr, "\
Usage: %s [-g] [-O] [-p] [-c] [-D lib] [-o outfile] [-x lang] [-dc]\n\
             [-v] [--kill] [--help] [--dump lib] [--check] [files]\n",
	  program);
#elif PCLUVENEER
  fprintf(stderr, "\
Usage: %s [-debug] [-optimize] [-profile] [-compile] [-create lib] [-spec]\n\
             [-link] [-use lib] [-cfile] [-kill] [-help] [-verbose] [files]\n",
	  program);
#else /* pcluVENEER */
  fprintf(stderr, "\
Usage: %s [-optimize] [-compile files] [-dump lib] [-specs files]\n\
             [-merge files] [-ce files] [-cfiles true|false] [-quit] [-help]\n\
             [-verbose]\n",
	  program);
#endif
  
  if (help)
#if CCVENEER
    fprintf(stderr, "\
Options are:\n\
     -g              Turn debugging on (the default)\n\
     -O              Turn optimization on\n\
     -p              Generate profiling information\n\
     -c              Compile named files\n\
     -D lib, --dump lib   Dump collected specifications to `lib'\n\
     --check         Check the named files' syntax and specifications\n\
     -o outfile      Save the linked program as `outfile'\n\
     -x lang         Interpret all the files left on the command line as being\n\
                     `lang' files. `lang' can be `clu' for CLU source files,\n\
                     `clu-library' for CLU library files, `clu-equate' for CLU\n\
                     equate files, `object' for object files and link\n\
                     libraries, or `none' to guess which language based on a\n\
                     file's suffix.\n\
     -dc             Keep generated C source code\n\
     -v              Verbose: print out the pclu and cc commands generated\n\
     --kill          Kill the pclu server, if it exists\n\
     --help          Print this message\n");
#elif PCLUVENEER
    fprintf(stderr, "\
Options are:\n\
     -debug          Turn debugging on (the default)\n\
     -optimize       Turn optimization on\n\
     -profile        Generate profiling information\n\
     -compile        Compile named files\n\
     -create lib     Dump collected specifications to `lib'\n\
     -spec           Check the named files' syntax and specifications\n\
     -link outfile   Link the program and save it as `outfile'\n\
     -use lib        Use the specifications from `lib'\n\
     -cfile          Keep generated C source code\n\
     -verbose        Print out the pclu and cc commands generated\n\
     -kill           Kill the pclu server, if it exists\n\
     -help           Print this message\n");
#else /* pcluVENEER */
    fprintf(stderr, "\
Options include:\n\
     -optimize [time|space|false]  Turn optimization on or off (off is default)\n\
     -compile files  Compile named files\n\
     -dump lib       Dump collected specifications to `lib'\n\
     -specs files    Check the named Clu files' syntax and specifications\n\
     -merge files    Use the specifications from the libraries `files'\n\
     -ce files       Create a new CE from `files'\n\
     -cfiles [true|false]  Keep (or don't) generated C source code\n\
     -verbose        Print out the pclu and cc commands generated\n\
     -quit           Kill the pclu server, if it exists\n\
     -help           Print this message\n");
#endif
     
  exit(help ? 0 : 1);
}


void
addpcluarg(int *pcluargc, char ***pcluargv, int *pcluargvsiz, char *arg) {
  if (*pcluargc >= *pcluargvsiz) {
    *pcluargvsiz *= 2;
    *pcluargv = realloc(*pcluargv, *pcluargvsiz * sizeof(char *));
  }
  (*pcluargv)[*pcluargc] = arg;
  (*pcluargc)++;
}


void
signalmebaby(int crap)
{
  debug(("created!!"));
}


void
signalmebabytimeout(int crap)
{
  servertimeout = 1;
}


int
openpcluserversocket(char *serveraddr, int serverport)
{
  struct sockaddr_in serveraddress;
  int sock;
  
  memset(&serveraddress, 0, sizeof(struct sockaddr_in));
  serveraddress.sin_family = AF_INET;
  serveraddress.sin_addr.s_addr = inet_addr(serveraddr);
  serveraddress.sin_port = htons(serverport);
  
  sock = socket(AF_INET, SOCK_STREAM, 0);
  if (sock < 0) fatal("can't open the socket to connect to the pcluserver");
  
  if (connect(sock, (struct sockaddr *)&serveraddress,
	      sizeof(struct sockaddr_in)) < 0) {
    extern int errno;
    debug(("Fucking errno %d", errno));
    exit(0);
    return -1;
  }

  return sock;
}


/* quotestring  Return a quoted string for the input string str. Str must be
     less than BUFSIZ characters long. The return value is a static buffer
     overwritten for each call, unless no quoting was required on str.  */
char *
quotestring(char *str)
{
  char doquoting = 0;
  static char buf[BUFSIZ], *trav;
  
  if (!strpbrk(str, "`\'\"\\\n\r\t\f\v ")) return str;

  trav = buf;
  *trav++ = '\'';
  while (*str)
    switch (*str) {
      
    case '\n':
      *trav++ = '\\';
      *trav++ = 'n';
      break;
      
    case '\f':
      *trav++ = '\\';
      *trav++ = 'f';
      break;
      
    case '\v':
      *trav++ = '\\';
      *trav++ = 'v';
      break;
      
    case '\'': case '\\': 
      *trav++ = '\\';
      /* fall through */
      
    default:
      *trav++ = *str++;
      
    }
  *trav++ = '\'';
  *trav++ = 0;
  return buf;
}


void
obtaincwd(void)
{
  cwd = malloc(BUFSIZ + 1);
  if (!getcwd(cwd, BUFSIZ)) {
    free(cwd);
    cwd = NULL;
  } else {
    cwdlen = strlen(cwd);
    if (cwd[cwdlen - 1] == '/') cwd[--cwdlen] = 0;
  }
}


char *messages[] = { "Creating DU specs from ",
		       "Merging ",
		       "Optimizing ",
		       "Compiling ",
		       "Dumped to ",
		       "Adding to CE from ",
		       "Un-Merging ",
		       CC_ERROR_STRING,
		       "Undefined",
		       NULL };
int messagelens[] = { 23, 8, 11, 10, 10, 18, 11, CC_ERROR_STRING_LEN, 9,
			0 };
int messageshutup[] = { 0, 0, 0, 0, 0, 0, 1, 2, 3, 0 };

char *vmessages[] = { "Un-Merging ",
		       NULL };
int vmessagelens[] = { 11, 0 };


void
filterpcluoutput(FILE *f, int verbose)
{
  char buf[BUFSIZ], *currentfile, *cc, **mes;
  int line, *meslens, reportedredeclaration = 0;

  currentfile = mystrdup("(no current file)");
  if (!cwd) obtaincwd();
  
  while (!feof(f) && fgets(buf, BUFSIZ, f) && strcmp(buf, QUITECHOSTR)) {
    
    if (verbose == 2) fputs(buf, stderr);
    else if (verbose) {
      for (mes = vmessages, meslens = vmessagelens; *mes; mes++, meslens++)
	if (!strncmp(buf, *mes, *meslens))
	  break;
      if (!*mes) fputs(buf, stderr);
    }      
    
    /* A completely blank line means the pipe has closed  */
    if (!*buf) break;
    
    /* Ignore blank lines  */
    cc = buf;
    while (isspace(*cc)) cc++;
    if (!*cc) continue;
    
    /* Ignore times  */
    if (!strncmp(buf, "time = ", 7)) continue;
    
    /* Error messages start with a number; everything else is suspect  */
    if (isalpha(*buf)) {
      /* Detect one of the stupid PCLU messages we know about  */
      for (mes = messages, meslens = messagelens; *mes; mes++, meslens++)
	if (!strncmp(buf, *mes, *meslens))
	  break;
      /* If it was one of those, ignore it, but set the current file to the
	 file it contained  */
      if (*mes && messageshutup[mes - messages] < 2) {
	char *mcc = strchr(buf, ':');
	if (mcc) *mcc = 0;
	free(currentfile);
	if (cwd && !strncmp(buf + *meslens, cwd, cwdlen))
	  currentfile = mystrdup(buf + *meslens + cwdlen + 1);
				/* + 1 to remove the slash after $cwd  */
	else
	  currentfile = mystrdup(buf + *meslens);
	cc = strchr(currentfile, '\n');
	if (cc) *cc = 0;
	if (mcc && !messageshutup[mes - messages] && !verbose)
	  fprintf(stderr, "%s:%s", currentfile, mcc + 1);
	continue;
      }
      if (*mes && messageshutup[mes - messages] == 2)	/* CC errors */
	if (strstr(buf, "redeclar")) {
	  fprintf(stderr, "%s: Did you declare a procedure, iterator, or cluster twice?\n",
		  currentfile);
	  if (!reportedredeclaration) {
	    reportedredeclaration = 1;
	    fprintf(stderr, "%s: (If you did, you will get many useless error messages from\n\
%s: the C compiler. If not, then something is really messed up.)\n",
		    currentfile, currentfile);
	  }
	}
      if (*mes && messageshutup[mes - messages] == 3)	/* errors which aren't
							   CC or #-started */
	errorcode = 1;
    }
    
    /* Error messages start with digits, context with spaces  */
    if (isdigit(*buf)) {
      errorcode = 1;
      for (cc = buf; isdigit(*cc); cc++) ;
      *cc++ = 0;
      while (isspace(*cc)) cc++;
      if (!verbose)
	fprintf(stderr, "%s:%s: %s", currentfile, buf, cc);
    } else if (!verbose) fputs(buf, stderr);
  }
  
  free(currentfile);
  fclose(f);
}


void
contactpcluserver(int argc, char **argv)
{
  char neednewserver = 1;
  FILE *f = fopen(pcluservertmpfile, "r");
  int serverport, socket, i;
  char serveraddrbuf[BUFSIZ], *thing, c;
  
  if (f) neednewserver = 0;
  
  if (neednewserver) {
    char mypid[BUFSIZ];
    int pgroup = getpgrp(getppid());
    sprintf(mypid, "%d", getpid());
    if (fork() == 0) {
      setpgrp(0, pgroup);
      execlp(PCLUSERVERCOMMAND, PCLUSERVERCOMMAND, pcluservertmpfile,
	     mypid, NULL);
    }
    servertimeout = 0;
    signal(SIGALRM, signalmebabytimeout);
    alarm(SERVERTIMEOUT);
    signal(SIGUSR1, signalmebaby);
    pause();
    signal(SIGUSR1, SIG_IGN);
    signal(SIGALRM, SIG_IGN);
    f = fopen(pcluservertmpfile, "r");
    if (!f) fatal("could not start up a pcluserver");
  }
  
  fgets(serveraddrbuf, BUFSIZ, f);
  thing = strrchr(serveraddrbuf, '\n');
  if (thing) *thing = 0;
  if (!fscanf(f, "%d", &serverport)) serverport = -1;
  fclose(f);
  
  debug(("connecting to server %d", serverport));
  if (serverport > 0)
    socket = openpcluserversocket(serveraddrbuf, serverport);
  if (socket < 0 || serverport < 0) {
    warning("the pclu server looks like it's dead; starting a new one");
    unlink(pcluservertmpfile);
    contactpcluserver(argc, argv);
    return;
  }

  debug(("writing information"));
  f = fdopen(socket, "w");
  fprintf(f, "#userid %d ", getuid());
  {
    char buf[BUFSIZ];
    if (getcwd(buf, BUFSIZ)) fprintf(f, "#cwd %s ", quotestring(buf));
  }
  for (i = 1; i < argc; i++)
    fprintf(f, "%s ", quotestring(argv[i]));
  fputc('\n', f);
  fflush(f);
  /* Even though we're done with the stream, don't close it; that'll close the
     socket, and that would be bad. We want return information from it. */
  
  debug(("reading information"));
  f = fdopen(socket, "r");
  if (!f) warning("couldn't give you pclu's output for some reason");
  else
#if CCVENEER || PCLUVENEER
  filterpcluoutput(f, verbose);
#else
  filterpcluoutput(f, 2);
#endif
}


/* optcmp  Returns zero if and only if opt is an initial substring of desc,
     and also opt has at least n characters. */
int
optcmp(char *opt, char *desc, int n)
{
  for (; *opt && *desc; n--)
    if (*opt++ != *desc++) return 1;
  return n > 0 || *opt;
}


void
addrealfile(struct thingtodo **tdd, char *file, enum action filetype)
{
  enum action thisfiletype = filetype;
  struct thingtodo *tdd1;
  char dowarning = 0;
  if (filetype == GUESS) {
    char *dot = strrchr(file, '.');
    if (!dot) thisfiletype = OBJECT, dowarning = 1;
    else if (!strcmp(dot, ".clu")) thisfiletype = COMPORSPEC;
    else if (!strcmp(dot, ".spc")) thisfiletype = SPECCHECK;
    else if (!strcmp(dot, ".equ")) thisfiletype = EQUATE;
    else if (!strcmp(dot, ".lib")) thisfiletype = LIBRARY;
    else if (!strcmp(dot, ".o") || !strcmp(dot, ".a"))
      thisfiletype = OBJECT;
    else thisfiletype = OBJECT, dowarning = 1;
  } else if (filetype == ERROR) {
    warning("unrecognized command `%s' (passing through to pclu)", file);
    thisfiletype = PCLU_CRAP;
  }
#if PCLUVENEER
  if (dowarning) {
    warning("`%s' has an unrecognized suffix", file);
    warning("I'm assuming it's an object file.");
  }
#endif
  tdd1 = malloc(sizeof(struct thingtodo));
  tdd1->name = file;
  tdd1->action = thisfiletype;
  tdd1->next = NULL;
  if (*tdd) (*tdd)->next = tdd1;
  tdd1->prev = *tdd;
  *tdd = tdd1;
}


char *
parsepcluhome(char *in)
{
  static char buf[BUFSIZ];
  *buf = 0;
  if (*in == '~') strcpy(buf, CLUHOME), in++;
  strcat(buf, in);
  return buf;
}


#if CCVENEER
#define DEBUGOPT    "-g", 2
#define OPTIMIZEOPT "-O", 2
#define PROFILEOPT  "-p", 2
#define COMPILEOPT  "-c", 2
#define DUMPOPT     "-D", 2
#define DUMPOPT2    "--dump", 3
#define CHECKOPT    "--check", 3
#define OUTOPT      "-o", 2
#define LANGUAGEOPT "-x", 2
#define CFILEOPT    "-dc", 3
#define KILLOPT     "--kill", 3
#define HELPOPT     "--help", 3
#define VERBOSEOPT  "-v", 2

#elif PCLUVENEER
#define DEBUGOPT    "-debug", 2
#define OPTIMIZEOPT "-optimize", 2
#define PROFILEOPT  "-profile", 2
#define COMPILEOPT  "-compile", 3
#define DUMPOPT     "-create", 3
#define CHECKOPT    "-spec", 2
#define LINKOPT     "-link", 2
#define USEOPT      "-use", 2
#define CFILEOPT    "-cfile", 3
#define KILLOPT     "-kill", 2
#define HELPOPT     "-help", 2
#define VERBOSEOPT  "-verbose", 2

#elif pcluVENEER
#define COMPILEOPT  "-compile", 3
#define DUMPOPT     "-dump", 2
#define CHECKOPT    "-specs", 2
#define LANGLIBOPT  "-merge", 3
#define LANGEQUOPT  "-ce", 3
#define CFILESOPT   "-cfiles", 3
#define KILLOPT     "-quit", 2
#define HELPOPT     "-help", 2
#define VERBOSEOPT  "-verbose", 2

#endif

void
main (int argc, char *argv[])
{
  char **pcluargv;		/* the command line to pass to pclu */
  int pcluargvsiz;		/* the size of pclucmdline */
  int pcluargc;			/* # of arguments in pcluargv */
  char buf[BUFSIZ];		/* a buffer */
  
  int optionnum;		/* the option we're currently processing */
  char *option;			/* the same */
  
  char debugging = 1;		/* debugging? >0, yes; >1, yes explicitly */
  char optimizing = 0;		/* optimizing? >0, yes; >1, yes explicitly */
  char profiling = 0;		/* profiling? >0, yes; >1, yes explicitly */
  char anydumps = 0;		/* any libraries dumped? >0, yes */

  char keepcfiles = 0;		/* if !0, keep the C files behind */
  
  enum action action;		/* what are we supposed to do with the
				   succeeding files? */
  enum action filetype;	  	/* what kind of files are we getting? */
  char compiledfiles = 0;	/* any files to compile? */
  char specedfiles = 0;		/* any files to spec check? */
  
  struct thingtodo *tdd = NULL;	/* what are we doing? */
  struct thingtodo *tdd1, *firsttdd;

  char *outputfile = NULL;

  char donebefore;

  sprintf(pcluservertmpfile, PCLUSERVERTMPFILE, getuid());
  
  program = argv[0];
  option = strrchr(program, '/');
  if (option) program = option + 1;
  
  pcluargvsiz = 200;
  pcluargv = malloc(pcluargvsiz * sizeof(char *));
  pcluargc = 0;
  addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, PCLUCOMMAND);

#if CCVENEER
  action = LINK;
  filetype = GUESS;
#elif PCLUVENEER
  action = SORTOFCOMPILE;
  filetype = GUESS;
#else
  action = ERROR;
  filetype = ERROR;
#endif

  if (argc < 2) usage(0);
  
  /* Parse the options, producing the struct thingtodo tree. */

  optionnum = 1;
  while (optionnum < argc) {
    
    option = argv[optionnum++];
    
#if pcluVENEER
    if (option[0] == '-') option[0] == '#';
    addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, mystrdup(option));
    /* Turn '#' options into '-' options.  */
    if (option[0] == '#') option[0] == '-';
#endif
    
    if (option[0] == '-') {

#if pcluVENEER
      filetype = GUESS;
#endif

#ifdef DEBUGOPT
      if (!optcmp(option, DEBUGOPT)) {
	debugging = 2;
	if (optimizing > 1)
	  fatal("cannot debug and optimize simultaneously");
	else optimizing = 0;

#else
      if (0) {
#endif
	
#ifdef OPTIMIZEOPT
      } else if (!optcmp(option, OPTIMIZEOPT)) {
	optimizing = 2;
	if (debugging > 1)
	  fatal("cannot debug and optimize simultaneously");
	else debugging = 0;
#endif

#ifdef PROFILEOPT
      } else if (!optcmp(option, PROFILEOPT)) {
	profiling = 2;
#endif

#ifdef LANGUAGEOPT
      } else if (!optcmp(option, LANGUAGEOPT)) {
	if (optionnum >= argc) usage(0);
	else option = argv[optionnum++];
	if (!strcmp(option, "clu")) filetype = COMPILE;
	else if (!strcmp(option, "clu-library")) filetype = LIBRARY;
	else if (!strcmp(option, "clu-equate")) filetype = EQUATE;
	else if (!strcmp(option, "object")) filetype = OBJECT;
	else if (!strcmp(option, "none")) filetype = GUESS;
	else fatal("unknown language: %s", option);
#endif

#ifdef LANGLIBOPT
      } else if (!optcmp(option, LANGLIBOPT)) {
	filetype = LIBRARY;
#endif

#ifdef LANGEQUOPT
      } else if (!optcmp(option, LANGEQUOPT)) {
	filetype = EQUATE;
#endif

#ifdef USEOPT
      } else if (!optcmp(option, USEOPT)) {
	if (optionnum >= argc) usage(0);
	option = argv[optionnum++];
	addrealfile(&tdd, option, LIBRARY);
#endif

      } else if (!optcmp(option, COMPILEOPT)) {
#if !pcluVENEER
	if (action == SPECCHECK)
	  fatal("can't both compile and check specs");
#if PCLUVENEER
	if (action == LINK)
	  fatal("can't both link and compile");
#endif
#else
	filetype = COMPILE;
#endif
	action = COMPILE;

      } else if (!optcmp(option, CHECKOPT)) {
#if !pcluVENEER
	if (action == COMPILE)
	  fatal("can't both compile and check specs");
#if PCLUVENEER
	if (action == LINK)
	  fatal("can't both link and check specs");
#endif
#else
	filetype = SPECCHECK;
#endif
	action = SPECCHECK;

#ifdef LINKOPT
      } else if (!optcmp(option, LINKOPT)) {
	if (action == SPECCHECK)
	  fatal("can't both compile and check specs");
	if (action == COMPILE)
	  fatal("can't both link and compile");
	if (optionnum >= argc) usage(0);
	else option = argv[optionnum++];
	outputfile = option;
	action = LINK;
#endif

#ifdef OUTOPT
      } else if (!optcmp(option, OUTOPT)) {
	if (optionnum >= argc) usage(0);
	else option = argv[optionnum++];
	outputfile = option;
#endif
	
      } else if (!optcmp(option, KILLOPT)) {
	char buf[BUFSIZ];
	FILE *f = fopen(pcluservertmpfile, "r");
	if (!f) warning("I don't think there's a pcluserver running.");
	else {
	  pid_t serverpid;
	  fgets(buf, BUFSIZ, f);
	  fgets(buf, BUFSIZ, f);
	  fscanf(f, "%d", &serverpid);
	  kill(serverpid, SIGHUP);
	  fclose(f);
	}
	exit(0);
	
      } else if (!optcmp(option, DUMPOPT)
#ifdef DUMPOPT2
		 || !optcmp(option, DUMPOPT2)
#endif
		 ) {
#if !pcluVENEER
	if (action == COMPILE)
	  fatal("can't both compile and check specifications");
#endif
	if (optionnum >= argc) usage(0);
	option = argv[optionnum++];
#if pcluVENEER
	addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, option);
#endif
	action = SPECCHECK;
	addrealfile(&tdd, option, DUMPLIBRARY);
	anydumps = 1;

#ifdef CFILEOPT
      } else if (!optcmp(option, CFILEOPT)) {
	keepcfiles = 1;
#endif
	
#ifdef CFILESOPT
      } else if (!optcmp(option, CFILESOPT)) {
	if (optionnum >= argc) usage(0);
	option = argv[optionnum++];
#if pcluVENEER
	addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, option);
#endif
	keepcfiles = (tolower(*option) == 't');
#endif
	
      } else if (!optcmp(option, VERBOSEOPT)) {
	verbose = 1;
#if pcluVENEER
	pcluargc--;
#endif

#if !pcluVENEER
      } else if (!strncmp(option, "-l", 2) || !strncmp(option, "-L", 2)) {
	addrealfile(&tdd, option, C_CRAP);
#endif
	
      } else if (!optcmp(option, HELPOPT)) {
	usage(1);
      }
	
#if !pcluVENEER
	else usage(0);
#endif
      
    } else
      addrealfile(&tdd, option, filetype);
    
  }

  if (action == SORTOFCOMPILE) action = COMPILE;
    
  /* Go back down the struct thingtodo tree and build the command line
     for pclu. Note that we shouldn't do this for the pclu veneer!!  */
  tdd1 = tdd;
  while (tdd1 && tdd1->prev) tdd1 = tdd1->prev;
  firsttdd = tdd1;
#if !pcluVENEER
  if (keepcfiles) {
    addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, "#cfiles");
    addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, "true");
  }
  if (optimizing) {
    addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, "#optimize");
  }
  if (profiling) {
    addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, "#profile");
    addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, "true");
  }
  if (anydumps) {
    addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, "#newlib");
  }
  for (tdd1 = firsttdd, donebefore = 0; tdd1; tdd1 = tdd1->next)
    if (tdd1->action == LIBRARY) {
      if (!donebefore) {
	addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, "#merge");
	donebefore = 1;
      }
      addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, tdd1->name);
    }
  for (tdd1 = firsttdd, donebefore = 0; tdd1; tdd1 = tdd1->next)
    if (tdd1->action == EQUATE) {
      if (!donebefore) {
	addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, "#ce");
	donebefore = 1;
      }
      addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, tdd1->name);
    }
#endif
  /* ...but we still want to make sure input files were specified for the
     pclu veneer.  */
  for (tdd1 = firsttdd, donebefore = 0; tdd1; tdd1 = tdd1->next)
    if (tdd1->action == COMPORSPEC) {
      if (!donebefore) {
	if (action == COMPILE || action == LINK) {
#if !pcluVENEER
	  addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, "#compile");
#endif
	  compiledfiles = 1;
	} else { /* action == SPECCHECK */
#if !pcluVENEER
	  addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, "#specs");
#endif
	  specedfiles = 1;
	}
	donebefore = 1;
      }
#if !pcluVENEER
      addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, tdd1->name);
#endif
    }
  for (tdd1 = firsttdd, donebefore = 0; tdd1; tdd1 = tdd1->next)
    if (tdd1->action == COMPILE) {
      if (!donebefore) {
#if !pcluVENEER
	addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, "#compile");
#endif
	donebefore = 1;
	compiledfiles = 1;
      }
#if !pcluVENEER
      addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, tdd1->name);
#endif
    }
  for (tdd1 = firsttdd, donebefore = 0; tdd1; tdd1 = tdd1->next)
    if (tdd1->action == SPECCHECK) {
      if (!donebefore) {
#if !pcluVENEER
	addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, "#specs");
#endif
	donebefore = 1;
	specedfiles = 1;
      }
#if !pcluVENEER
      addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, tdd1->name);
#endif
    }
#if !pcluVENEER
  for (tdd1 = firsttdd; tdd1; tdd1 = tdd1->next)
    if (tdd1->action == DUMPLIBRARY) {
      addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, "#dump");
      addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, tdd1->name);
    }
#endif
    
    
#if !pcluVENEER
  if (action == COMPILE && !compiledfiles ||
      action == SPECCHECK && !specedfiles)
    fatal("no files specified to %s", action == COMPILE ? "compile" : "spec");
#endif
    
  if (action != LINK || compiledfiles) {
    
    if (verbose) {
      int i;
      for (i = 0; i < pcluargc; i++)
	fprintf(stderr, "%s ", pcluargv[i]);
      fprintf(stderr, "\n");
    }
    
    contactpcluserver(pcluargc, pcluargv);
    
  }

  if (action == LINK) {
    char buf[BUFSIZ];
    free(pcluargv);
    pcluargv = malloc(pcluargvsiz * sizeof(char *));
    pcluargc = 0;
    addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, CCLDCOMMAND);
    
    if (outputfile) {
      addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, "-o");
      addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, outputfile);
    }
#ifdef STRIPNOPROFILEOPT
    if (!profiling) {
      addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, STRIPNOPROFILEOPT);
    }
#endif
    
    for (tdd1 = firsttdd; tdd1; tdd1 = tdd1->next)
      if (tdd1->action == COMPORSPEC || tdd1->action == COMPILE) {
	char *cc;
	strcpy(buf, tdd1->name);
	cc = strrchr(buf, '.');
	if (cc) strcpy(cc, ".o");
	else strcat(buf, ".o");
	addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, mystrdup(buf));
      } else if (tdd1->action == OBJECT || tdd1->action == C_CRAP)
	addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, tdd1->name);
    
    sprintf(buf, "-L%s", parsepcluhome(PCLULIBDIR));
    addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, mystrdup(buf));
    if (debugging)
      addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, PCLUDEBUGLIB);
    else
      addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, PCLUOPTIMIZELIB);
    addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, PCLUOTHERLIB);
#ifdef CCLDOTHERLIBS
    {
      char *ccldotherlibs[] = { CCLDOTHERLIBS, NULL }, **ccld;
      for (ccld = ccldotherlibs; *ccld; ccld++)
	addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, *ccld);
    }
#endif
    
    if (verbose) {
      int i;
      for (i = 0; i < pcluargc; i++)
	fprintf(stderr, "%s ", pcluargv[i]);
      fprintf(stderr, "\n");
    }
        
    addpcluarg(&pcluargc, &pcluargv, &pcluargvsiz, NULL);
    execvp(CCLDCOMMAND, pcluargv);
  }
    
  exit(errorcode);
}
