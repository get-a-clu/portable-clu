#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <stdarg.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include "pcluserver.h"

#define PCLUSERVERPORT 7049

#ifdef DEBUG
#define DEBUGPREFIX ""
#define debug(x) Debug x
#else
#define debug(x)
#endif


int sockfd;
long thishostsinetaddress;
int insearch = 0;
int verbose = 0;
char *pcluservertmpfile;


struct onepclu {
  uid_t userid;
  char *cwd;
  FILE *pcluin, *pcluout;
  pid_t pclupid;
  pid_t listenerpid;
  time_t recently;
  int used;
  int count;
  char **ce;
  char **libs;
  time_t *cetimes;
  time_t *libtimes;
  char optimizing;
  char debugging;
  char profiling;
  char keepcfiles;
  struct onepclu *next;
  int zombee;
};


struct onepclu *pclus = NULL, *readingpclu;


void hangup(int);

void
fatal (char *string, ...)
{
  va_list al;
  va_start(al, string);
  fprintf(stderr, "pcluserver: ");
  vfprintf(stderr, string, al);
  fputc('\n', stderr);
  va_end(al);
  hangup(1);
}


#ifdef DEBUG
void
Debug(char *string, ...)
{
  va_list al;
  va_start(al, string);
  fputc('[', stderr);
  fprintf(stderr, DEBUGPREFIX);
  vfprintf(stderr, string, al);
  fprintf(stderr, "] ");
  va_end(al);
}
#endif


void
pcluprintf(struct onepclu *pc1, char *string, ...)
{
  va_list al;
  va_start(al, string);
  vfprintf(pc1->pcluout, string, al);
  if (verbose)
    vfprintf(stderr, string, al);
  va_end(al);
}


char *
parsepcluhome(char *in)
{
  static char buf[BUFSIZ];
  *buf = 0;
  if (*in == '~') {
    strcpy(buf, CLUHOME);
    in++;
  }
  strcat(buf, in);
  return buf;
}


int
setupsocket(void)
{
  struct sockaddr_in serveraddress;
  int port = PCLUSERVERPORT - 1;

  sockfd = socket(AF_INET, SOCK_STREAM, 0);
  if (sockfd < 0) fatal("can't open a socket to listen in");

  do {
    memset(&serveraddress, 0, sizeof(struct sockaddr_in));
    serveraddress.sin_family = AF_INET;
    serveraddress.sin_addr.s_addr = INADDR_ANY;
				/* should be thishostsinetaddress
				   for security?... */
    ++port;
    serveraddress.sin_port = htons(port);
  } while (bind(sockfd, (struct sockaddr *)&serveraddress,
		sizeof(serveraddress)) < 0);
  
  listen(sockfd, 5);

  return port;
}


char *
mystrdup(char *inchar)
{
  char *x = malloc(strlen(inchar) + 1);
  strcpy(x, inchar);
  return x;
}


char *
wordquote(char *q)
{
  static char buf[BUFSIZ], *t = buf, space = 1;
  while (*q) {
    if (isspace(*q) && !space) *t++ = ' ', space = 1;
    else {
      if (space && (*q == '-' || *q == '#')) *t++ = '\\';
      space = 0;
      if (*q == '\\') *t++ = '\\';
      *t++ = *q;
    } 
    q++;
  }
  return buf;
}


char *
readword(FILE *f)
{
  static char buf[BUFSIZ];
  char *trav = buf, inquotes = 0;
  int cc;
  do { cc = fgetc(f); } while (isspace(cc) && cc != '\n');
  if (cc == '\n' || cc == EOF) return NULL;
  do {
    if (cc == '\'' || cc == '\"') inquotes = cc;
    else if (cc == '\\') {
      cc = fgetc(f);
      if (cc == 'n') *trav = '\n';
      else if (cc == 'r') *trav = '\r';
      else if (cc == 'f') *trav = '\f';
      else if (cc == 't') *trav = '\t';
      else if (cc == 'v') *trav = '\v';
      else if (cc == 'a') *trav = '\a';
      else if (cc == 'b') *trav = '\b';
      else *trav = cc;
    } else *trav = cc;
    trav++;
    cc = fgetc(f);
  } while (!isspace(cc) && cc != EOF);
  if (cc == EOF) return NULL;
  *trav = 0;
  ungetc(cc, f);
  return buf;
}


char **
newstringset(void)
{
  char **x = malloc(sizeof(char *));
  *x = NULL;
  return x;
}


char **
addstringset(char **m, char *q)
{
  int i = 0;
  char **mm;
  for (mm = m; *mm; mm++) {
    if (!strcmp(q, *mm)) return m;
    i++;
  }
  m = realloc(m, sizeof(char *) * (i + 2));
  m[i] = mystrdup(q);
  m[i+1] = NULL;
  return m;
}


void
freestringset(char **m)
{
  char **mm;
  for (mm = m; *mm; mm++) free(*mm);
  free(m);
}


char **
copystringset(char **m)
{
  char **mret, **mm;
  int i = 0;
  for (mm = m; *mm; mm++) i++;
  mret = malloc(sizeof(char *) * (i + 1));
  for (mm = mret; *m; m++) *mm++ = mystrdup(*m);
  *mm = NULL;
  return mret;
}


time_t
getfiletime(char *name)
{
  struct stat thing;
  if (!stat(name, &thing)) return thing.st_mtime;
  else return 0;
}


char **
xorstringset(char **m1, char **m2, time_t *time2, char ***m2notm1)
{
  char **mm, **mret;
  int m2num;
  char fine;
  if (m2notm1) *m2notm1 = newstringset();
  mret = copystringset(m1);
  for (m2num = 0; *m2; m2++, m2num++) {
    for (fine = 0, mm = mret; !fine && *mm; mm++)
      if (!strcmp(*mm, *m2) &&
	  (!time2 || time2[m2num] &&
	   time2[m2num] == getfiletime(*m2))) {
	free(*mm);
	for (; *mm; mm++) mm[0] = mm[1];
	fine = 1;
      }
    if (!fine && !m2notm1) {
      freestringset(mret);
      return NULL;
    } else if (!fine)
      *m2notm1 = addstringset(*m2notm1, *m2);
  }
  return mret;
}


#ifdef DEBUG
#define debugstringset(x) Debugstringset(x, #x)

void
Debugstringset(char **strs, char *id)
{
  fputc('[', stderr);
  fprintf(stderr, DEBUGPREFIX);
  while (*strs) fprintf(stderr, "%s ", *strs++);
  fprintf(stderr, ":%s] ", id);
}
#else
#define debugstringset(x)
#endif


void
reap(int whatever)
{
  time_t now;
  struct onepclu *pc1, *pc11;
  alarm(PCLUMULTITIMEOUT);
  signal(SIGALRM, reap);
  if (insearch) return;
  debug(("Death's arrived!"));
  now = time(NULL);
  for (pc1 = pclus; pc1; pc1 = pc1->next)
    if (!pc1->used && !pc1->listenerpid && pc1->pclupid && !pc1->zombee &&
	(now - pc1->recently > PCLUTIMEOUT ||
	 pc1->count > 1 && now - pc1->recently > PCLUMULTITIMEOUT)) {
      debug(("Reaping %d", pc1->pclupid));
      kill(pc1->pclupid, SIGINT);
      for (pc11 = pclus; pc11; pc11 = pc11->next)
	if (pc11->userid == pc1->userid)
	  pc11->count--;
    }
}


void
createpcluprocess(struct onepclu *pc1)
{
  int peep[2], poop[2];
  pid_t baby;
  if (pipe(peep) < 0) fatal("couldn't open pipe");
#ifndef ONE_PIPES_ENOUGH
  if (pipe(poop) < 0) fatal("couldn't open pipe");
#else
  poop[1] = peep[0];
  poop[0] = peep[1];
#endif
  debug(("forking pclu"));
  baby = fork();
  if (baby < 0) fatal("cannot fork to run pclu");
  else if (baby == 0) {
    char *thing = parsepcluhome(PCLUCOMMAND);
    dup2(peep[0], fileno(stdin));
    dup2(poop[1], fileno(stdout));
    dup2(poop[1], fileno(stderr));
    if (execlp(thing, thing, NULL) < 0)
      fatal("cannot run pclu");
  } else {
    char buf[BUFSIZ];
    pc1->pclupid = baby;
    pc1->pcluout = fdopen(peep[1], "w");
    pc1->pcluin = fdopen(poop[0], "r");
    debug(("waiting for prompt from %d", baby));
    while (!feof(pc1->pcluin) && fgets(buf, BUFSIZ, pc1->pcluin)) {
      if (!strcmp(buf, PCLUPROMPT)) break;
      debug(("%s", buf));
    }
    if (feof(pc1->pcluin)) {
      debug(("trying again"));
      createpcluprocess(pc1);
      return;
    }
    debug(("got pclu"));
  }
}


struct onepclu *
findonepclu(uid_t userid)
{
  struct onepclu *pc1 = pclus;
  int count = 1;
  insearch = 1;
  while (pc1 && userid != pc1->userid)
    pc1 = pc1->next;
  if (pc1 && pc1->used) {
    for (pc1 = pclus; pc1; pc1 = pc1->next)
      if (pc1->userid == userid)
	count = ++pc1->count;
    pc1 = NULL;
  }
  if (!pc1) {
    debug(("Making new pclu"));
    pc1 = calloc(1, sizeof(struct onepclu));
    pc1->userid = userid;
    pc1->next = pclus;
    pclus = pc1;
    pc1->ce = newstringset();
    pc1->libs = newstringset();
    pc1->count = count;
#ifdef HAVE_PCLU
    createpcluprocess(pc1);
#else
    pc1->pcluout = stderr;
#endif
  }
  insearch = 0;
  return pc1;
}


void
onepcluupdate(struct onepclu *thispclu, char optimizing, char debugging,
	      char profiling, char keepcfiles, char **ce, char **libs)
{
  char **newce, **newlibs, **newerlibs, **mm;
  int nm;
  time_t *newtime;
  
  if (thispclu->optimizing != optimizing) {
    pcluprintf(thispclu, "#optimize %s ", optimizing ? "" : "false");
    thispclu->optimizing = optimizing;
  }
  if (thispclu->keepcfiles != keepcfiles) {
    pcluprintf(thispclu, "#cfiles %s ", keepcfiles ? "true" : "false");
    thispclu->keepcfiles = keepcfiles;
  }
  
  newce = xorstringset(libs, thispclu->libs, thispclu->libtimes, &newlibs);
  if (*newlibs) pcluprintf(thispclu, "#unmerge ");
  for (mm = newlibs; *mm; mm++) pcluprintf(thispclu, "%s ", *mm);
  freestringset(newlibs);
  if (*newce) pcluprintf(thispclu, "#merge ");
  for (mm = newce; *mm; mm++) pcluprintf(thispclu, "%s ", *mm);
  freestringset(newce);
  freestringset(thispclu->libs);
  thispclu->libs = copystringset(libs);
  
  for (nm = 0, newce = thispclu->libs; *newce; newce++) nm++;
  if (thispclu->libtimes) free(thispclu->libtimes);
  thispclu->libtimes = malloc(sizeof(time_t) * nm);
  for (newtime = thispclu->libtimes, newce = thispclu->libs; *newce;
       newce++, newtime++)
    *newtime = getfiletime(*newce);
  
  
  newce = xorstringset(ce, thispclu->ce, thispclu->cetimes, NULL);
  if (!newce) {
    freestringset(thispclu->ce);
    thispclu->ce = newstringset();
    if (*ce) pcluprintf(thispclu, "#ce ");
  } else {
    ce = newce;
    if (*ce) pcluprintf(thispclu, "#%sce ",
			*thispclu->ce ? "x" : "");
  }
  for (mm = ce; *mm; mm++) {
    pcluprintf(thispclu, "%s ", *mm);
    thispclu->ce = addstringset(thispclu->ce, *mm);
  }
  if (newce) freestringset(newce);
  
  for (nm = 0, newce = thispclu->ce; *newce; newce++) nm++;
  if (thispclu->cetimes) free(thispclu->cetimes);
  thispclu->cetimes = malloc(sizeof(time_t) * nm);
  for (newtime = thispclu->cetimes, newce = thispclu->ce; *newce;
       newce++, newtime++)
    *newtime = getfiletime(*newce);
}


void
finishresponse()
{
  char buf[BUFSIZ];
  while (fgets(buf, BUFSIZ, readingpclu->pcluin)) {
    if (!strcmp(buf, PCLUPROMPT)) break;
    debug(("{%s}", buf));
  }
  exit(0);
}


void
handleconnection(FILE *fi, FILE *fo)
{
  char *tempword;
  char *action = NULL;
  uid_t userid = 0;
  char **ce = newstringset(), **libs = newstringset();
  char ***stringsettoaddto = NULL;
  char *cwd = NULL;
  char buf[BUFSIZ];
  char keepcfiles = 0;
  char debugging = 1;
  char optimizing = 0;
  char profiling = 0;
  struct onepclu *thispclu;
  
  tempword = readword(fi);
  if (!tempword) return;
  
  if (!strcasecmp(tempword, "#userid")) {
    tempword = readword(fi);
    if (!tempword) return;
    if (tempword[0] != '#') {
      userid = strtol(tempword, NULL, 0);
      tempword = readword(fi);
    }
    if (!tempword) return;
  }
  
  if (!strcasecmp(tempword, "#cwd")) {
    tempword = readword(fi);
    if (!tempword) return;
    cwd = mystrdup(tempword);
    tempword = readword(fi);
    if (!tempword) return;
    chdir(cwd);
  }
  
  thispclu = findonepclu(userid);
  thispclu->recently = time(NULL);
  if (((!cwd || !thispclu->cwd) && cwd != thispclu->cwd) ||
      (cwd && thispclu->cwd && strcmp(cwd, thispclu->cwd))) {
    if (thispclu->cwd) free(thispclu->cwd);
    pcluprintf(thispclu, "#dir %s #bindir %s ", cwd, cwd);
    pcluprintf(thispclu, "#ce #newlib ");
    freestringset(thispclu->libs);
    freestringset(thispclu->ce);
    thispclu->libs = newstringset();
    thispclu->ce = newstringset();
    thispclu->cwd = cwd;
  } else free(cwd);
  

  while (tempword) {
    debug(("%s", tempword));
    if (tempword[0] == '#') {
      stringsettoaddto = NULL;
      if (action) free(action);
      action = mystrdup(tempword);
      if (!strcasecmp(action, "#cfiles")) {
	tempword = readword(fi);
	if (tempword && tempword[0] == 'f') keepcfiles = 0;
	else keepcfiles = 1;
	if (!tempword || tempword[0] == '#') continue;
      } else if (!strcasecmp(action, "#optimize")) {
	tempword = readword(fi);
	if (tempword && tempword[0] == 'f') optimizing = 0, debugging = 1;
	else optimizing = 2, debugging = 0;
	if (!tempword || tempword[0] == '#') continue;
      } else if (!strcasecmp(action, "#profile")) {
	tempword = readword(fi);
	if (!strcasecmp(tempword, "true")) profiling = 1;
	else profiling = 0;
      } else if (!strcasecmp(action, "#compile")
	       || !strcasecmp(action, "#specs")) {
	onepcluupdate(thispclu, optimizing, debugging, profiling,
		      keepcfiles, ce, libs);
	pcluprintf(thispclu, "%s ", action);
      } else if (!strcasecmp(action, "#newlib")) {
	freestringset(libs);
	libs = newstringset();
	freestringset(thispclu->libs);
	thispclu->libs = newstringset();
	pcluprintf(thispclu, "%s ", action);
      } else if (!strcasecmp(action, "#ce")) {
	freestringset(ce);
	stringsettoaddto = &ce;
      } else if (!strcasecmp(action, "#xce")) {
	stringsettoaddto = &ce;
      } else if (!strcasecmp(action, "#merge")) {
	stringsettoaddto = &libs;
      } else pcluprintf(thispclu, "%s ", action);
    } else {
      if (stringsettoaddto)
	*stringsettoaddto = addstringset(*stringsettoaddto, tempword);
      else
	pcluprintf(thispclu, "%s ", tempword);
    }
    
    tempword = readword(fi);
  }
  
 done:
  if (action) free(action);
  pcluprintf(thispclu, "\n");
  fflush(thispclu->pcluout);

  if (thispclu->pclupid > 0 && thispclu->pcluin) {
    pid_t child;
    thispclu->used++;
    child = fork();
    if (child == 0) {
      readingpclu = thispclu;
      signal(SIGPIPE, finishresponse);
      while (fgets(buf, BUFSIZ, thispclu->pcluin)) {
	if (!strcmp(buf, PCLUPROMPT)) break;
	else fputs(buf, fo);
	debug(("%s", buf));
	fflush(fo);
      }
      fputs(QUITECHOSTR, fo);
      fflush(fo);
      exit(0);
    } else if (child > 0) {
      thispclu->listenerpid = child;
      debug(("listener %d", child));
    }
  }
  
  freestringset(ce);
  freestringset(libs);
  if (action) free(action);
}


void
killtheundead(void)
{
  struct onepclu *pc1, *prevpc1 = NULL, *pc2;
  for (pc1 = pclus; pc1; pc1 = pc1->next)
    if (pc1->zombee) {
      for (pc2 = pclus; pc2; pc2 = pc2->next)
	if (pc2->userid == pc1->userid)
	  pc2->count--;
      freestringset(pc1->ce);
      freestringset(pc1->libs);
      if (pc1->cwd) free(pc1->cwd);
      if (prevpc1) prevpc1->next = pc1->next;
      else pclus = pc1->next;
      free(pc1);
    }
  if (!pclus) hangup(1);
}


void
serverloop(void)
{
  int newsocket;
  struct sockaddr_in clientaddress;
  int clientaddresslength = sizeof(struct sockaddr_in);
  FILE *input, *output;
  
  while (1) {
    debug(("looking..."));
    newsocket = accept(sockfd, (struct sockaddr *)&clientaddress,
		       &clientaddresslength);
    
    /* Signals cause interrupts; we don't want to die on those. */
    if (newsocket < 0) {
      if (errno == EINTR) {
	killtheundead();
	continue;
      } else fatal("error while accepting a connection");
    }

    debug(("...got it."));
    
    input = fdopen(newsocket, "r");
    output = fdopen(newsocket, "w");
    
    handleconnection(input, output);
    
    fclose(input);
    fclose(output);
    close(newsocket);
  }
}


void
childdies(int whatever)
{
  pid_t dead = wait(NULL);
  signal(SIGCHLD, childdies);
  if (dead > 0) {
    struct onepclu *pc1 = pclus;
    struct onepclu *prevpc1 = NULL;
    debug(("%d died", dead));
    while (pc1) {
      if (pc1->listenerpid == dead) {
	pc1->listenerpid = 0;
	pc1->used--;
	break;
      }
      if (pc1->pclupid == dead) {
	pc1->pclupid = 0;
	pc1->zombee = 1;
	break;
      }
      prevpc1 = pc1;
      pc1 = pc1->next;
    }
  }
}


void
hangup(int whatever)
{
  struct onepclu *pc1;
  debug(("AAAAAAGH!!!"));
  for (pc1 = pclus; pc1; pc1 = pc1->next) {
    if (pc1->pclupid > 0)
      kill(pc1->pclupid, SIGINT);
    if (pc1->listenerpid > 0)
      kill(pc1->listenerpid, SIGINT);
  }
  unlink(pcluservertmpfile);
  close(sockfd);
  exit(0);
}


#ifdef NEED_NETDIR
#include <netdir.h>
#endif

void
main(int argc, char *argv[])
{
  struct hostent *thishost;
  FILE *f;
  int i, port;
  pid_t processtokill;

#ifdef USE_GETHOSTNAME
  {
    char buf[BUFSIZ];
    gethostname(buf, BUFSIZ);
    thishost = gethostbyname(buf);
  }
#else
  thishost = gethostbyname(HOST_SELF_CONNECT);
#endif

  if (argc > 1) pcluservertmpfile = argv[1];
  else {
    pcluservertmpfile = malloc(strlen(PCLUSERVERTMPFILE) + 1);
    sprintf(pcluservertmpfile, PCLUSERVERTMPFILE, -1);
  }
  f = fopen(pcluservertmpfile, "w");
  memcpy(&thishostsinetaddress, thishost->h_addr, sizeof(thishost->h_addr));
  port = setupsocket();
  
  if (f) {
    struct in_addr in;
    in.s_addr = thishostsinetaddress;
    fprintf(f, "%s\n%d\n%d\n", inet_ntoa(in), port, getpid());
    debug(("bound to port %d", port));
    fclose(f);
  }
  
  signal(SIGCHLD, childdies);
  signal(SIGHUP, hangup);
  signal(SIGINT, hangup);

  alarm(PCLUMULTITIMEOUT);
  signal(SIGALRM, reap);
  
  for (i = 2; i < argc; i++)
    if (!strncmp(argv[i], "-verbose", 2)) verbose = 1;
    else {
      debug(("killing %s", argv[i]));
      processtokill = strtol(argv[i], NULL, 0);
      if (processtokill >= 0) kill(processtokill, SIGUSR1);
    }
  
  if (verbose) fprintf(stderr, "#pcluserver online\n");
  
  serverloop();
  
  hangup(1);
}
