
/* Copyright Massachusetts Institute of Technology 1990,1991 */

#ifndef lint
static char rcsid[] = "$Header: _change_signal.c,v 1.3 91/06/06 13:44:09 dcurtis Exp $";
#endif lint
/* $Log:	_change_signal.c,v $
 * Revision 1.3  91/06/06  13:44:09  dcurtis
 * added copyright notice
 * 
 * Revision 1.2  91/06/03  17:07:47  root
 * sparcstation compatibility: decompose a union variable
 * 
 * Revision 1.1  91/02/04  23:20:17  mtv
 * Initial revision
 * 
 */

/*						*/
/*						*/
/*		IMPLEMENTATION OF		*/
/*			_change_signal		*/
/*						*/

#include <signal.h>
#undef signal

#include "pclu_err.h"
#include "pclu_sys.h"

extern int errno;
extern CLUREF empty_string;

errcode _change_signal(sig, label, ans)
CLUREF sig, label, *ans;
{
int err;
struct sigvec vec, ovec;

	vec.sv_handler = (void (*)())label.ref;
	vec.sv_mask = 0xff7bf0e0;
	vec.sv_flags = 1;

	err = sigvec(sig.num, &vec, &ovec);
	if (err != 0) {
		elist[0] = _unix_erstr(errno);
		signal(ERR_not_possible);
		}
	ans->num = (int)ovec.sv_handler;
	signal(ERR_ok);
	}

