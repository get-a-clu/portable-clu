#ifndef lint
static char rcsid[] = "$Header: cons.c,v 1.2 91/05/06 12:25:40 dcurtis Exp $";
#endif
/* $Log:	cons.c,v $
 * Revision 1.2  91/05/06  12:25:40  dcurtis
 * *** empty log message ***
 * 
 * Revision 1.1  91/02/04  16:21:22  mtv
 * Initial revision
 * 
 */

/* Silly implementation of Lisp cons. Intentionally wastes lots of space */
/* to test collector.                                                    */
# include <stdio.h>
# include "cons.h"

int extra_count = 0;        /* Amount of space wasted in cons node */
int total = 0;

sexpr cons (x, y)
sexpr x;
sexpr y;
{
    register sexpr r;
    register int i;
    register int *p;
    
    extra_count++;
    extra_count %= 3000;

    r = (sexpr) gc_malloc(sizeof(struct SEXPR) + extra_count);
    total += 8 + extra_count;
    for (p = (int *)r; ((char *)p) < ((char *)r) + extra_count + 8; p++) {
	if (*p) {
	    fprintf(stderr, "Found nonzero at %lX\n", p);
	    abort(p);
        }
        *p = 13;
    }
    r -> sexpr_car = x;
    r -> sexpr_cdr = y;
    return(r);
}
