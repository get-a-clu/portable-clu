static int glob;
main()
{
int i;
char *foo;
	printf("%X stacktop\n", &i);
	printf("%X glob start\n", &glob);
	foo = malloc(10);
	printf("%X heap start\n", foo);
	}
