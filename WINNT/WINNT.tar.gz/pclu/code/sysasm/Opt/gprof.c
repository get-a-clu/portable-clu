


/* Copyright Massachusetts Institute of Technology 1990,1991 */

#ifndef lint
static char rcsid[] = "$Header: gprof.c,v 1.2 91/06/06 13:27:26 root Exp $";
#endif	/* lint */

/* $Log:        gprof.c,v $
 * Revision 1.2  91/06/06  13:27:26  root
 * added copyright notice
 * 
 * Revision 1.1  91/02/04  15:49:43  mtv
 * Initial revision
 * 
 */


/*                                              */
/*                                              */
/*              IMPLEMENTATION OF               */
/*                      xxx                     */
/*                                              */

#include "pclu_err.h"
#include "pclu_sys.h"
