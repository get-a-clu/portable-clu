
/*                                              */
/*                                              */
/*              IMPLEMENTATION OF               */
/*                 unix_cmd                     */
/*                                              */

#include <sys/types.h>		/* MSch, for wait() */

#include <sys/wait.h>
#undef signal
#include "pclu_err.h"
#include "pclu_sys.h"

#if !defined(LINUX) && !defined(WIN32) && !defined(_BSD)
extern char *system ();
#endif

errcode unix_cmd (input)
CLUREF input;
{
#if !defined(LINUX) && !defined(WIN32) && !defined(_BSD)
  char *result;	
#else
/* system(3) says: int system (const char *string), MSch */
  int result;
#endif

  CLUREF temp_str, n, num, size;
  errcode err;

  result = system ((char *) input.vec -> data);
/*      printf("err = %X, %X %X %X\n", err, WTERMSIG(err), WEXITSTATUS(err), WSTOPSIG(err)); */
#if !defined(LINUX) && !defined(WIN32) && !defined(_BSD)
  if (result == NULL)
#else
  if (result == 0)
#endif
    signal (ERR_ok);

  err = stringOPcons ("call to system failed: ", CLU_1, CLU_23, &temp_str);
  n.num = (long) result;
  err = intOPunparse (n, &num);
  err = stringOPconcat (temp_str, num, &temp_str);
  elist[0] = temp_str;
  signal (ERR_failure);
}
