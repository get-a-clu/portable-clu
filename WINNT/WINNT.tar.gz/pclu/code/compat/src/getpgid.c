
#include <errno.h>
#include <sys/types.h>

pid_t
getpgid (pid_t pid)
{

  errno=ENOSYS;
  perror("ERROR: getpgid not supported");
  
  return -1;
}
