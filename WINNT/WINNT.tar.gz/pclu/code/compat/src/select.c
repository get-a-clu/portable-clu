
#include <sys/unistd.h>

#include <sys/resource.h>
#include <sys/types.h>
#include <sys/time.h>

#include <errno.h>

int select (int nfds,
	    fd_set *readfds,
	    fd_set *writefds,
	    fd_set *exceptfds,
	    struct timeval *timeout)
{
  errno = ENOSYS;
  perror("ERROR: select not supported");

  return -1;
}



