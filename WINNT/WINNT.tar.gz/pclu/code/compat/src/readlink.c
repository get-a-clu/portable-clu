#include <errno.h>


int
readlink (const char *path, char *buf, int bufsiz)
{
  errno = ENOSYS;
  perror("ERROR: readlink not supported");

  return -1;
}
