
#include <signal.h>
#undef signal

int
killpg (pid_t pgrp, int sig)
{
  int ret;

  ret = kill((pid_t)(-(int)pgrp),sig);

  return ret;
}
