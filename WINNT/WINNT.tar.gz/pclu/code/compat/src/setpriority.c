
#include <sys/time.h>
#include <sys/resource.h>

#include <errno.h>

int setpriority (int which, int who, int prio)
{
  errno = ENOSYS;
  perror("ERROR: setpriority not supported");

  return -1;
}
