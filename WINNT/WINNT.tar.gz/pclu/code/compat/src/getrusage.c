  
#include <sys/resource.h>
#include <errno.h>

int getrusage(int who, struct rusage *rusage)
{

  errno=ENOSYS;
  perror("ERROR: getrusage not supported");

  return 0;			/* OK, it's a lie */
}
