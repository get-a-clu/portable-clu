
#include <sys/time.h>
#include <sys/resource.h>

#include <errno.h>


int
getpriority (int which, int who)
{
  errno=ENOSYS;
  perror ("ERROR: getpriority not supported");

  return -1;
}
