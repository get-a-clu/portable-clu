
#include <sys/resource.h>
#include <errno.h>

int setrlimit (int resource, const struct rlimit *rlp)
{
  errno = ENOSYS;
  perror("ERROR: setrlimit not supported");

  return -1;
}
