#include <errno.h>

int
nice (int incr)
{
				/* should be implemented via setpriority() */

  errno=ENOSYS;
  perror("ERROR: nice not supported");

  return -1;
}
