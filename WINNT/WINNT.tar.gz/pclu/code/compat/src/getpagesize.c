
#include <errno.h>

int
getpagesize (void)
{

  errno=ENOSYS;
  perror("ERROR: getpagezize not supported");

  return -1;
}

