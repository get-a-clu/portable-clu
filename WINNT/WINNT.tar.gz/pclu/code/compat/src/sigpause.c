
#include <signal.h>
#undef signal

int
sigpause (int sigmask)
{
  sigset_t sigset;
  int ret;

  sigemptyset(&sigset);
  sigaddset(&sigset,sigmask);
  
  ret=sigsuspend(&sigset);

  return ret;
}

