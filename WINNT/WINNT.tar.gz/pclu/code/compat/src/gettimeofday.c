
#include <sys/time.h>

#include <sys/timeb.h>		/* often exists */

int gettimeofday (struct timeval *tv, struct timezone *tz)
{
  struct timeb tb;

  ftime(&tb);

  memset(&tb,0,sizeof(struct timeb));

  tv->tv_sec = tb.time;
  tv->tv_usec = tb.millitm * 1000;

  tz->tz_minuteswest = tb.timezone;
  tz->tz_dsttime = tb.dstflag;
  
  return 0;
}
