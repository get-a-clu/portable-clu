/**
 **
 ** thanks to Dan Stromberg
 ** ftp.uci.edu/pub/generic/generic.tar.gz	(MSch)
 **
 **/

#include <fcntl.h>
#include <errno.h>


#define   LOCK_SH   1		/* shared lock */
#define   LOCK_EX   2		/* exclusive lock */
#define   LOCK_NB   4		/* don't block when locking */
#define   LOCK_UN   8		/* unlock */

int
flock(int fd, int operation)
{
  int             fun, res;
  struct flock    lock;

  if (operation < 0 || operation > LOCK_UN) {
    errno = EINVAL;
    return -1;
  }
  lock.l_whence = 0;
  lock.l_start = 0;
  lock.l_len = 0;
  if (operation & LOCK_UN) {
    lock.l_type = F_UNLCK;
    return fcntl(fd, F_SETLK, &lock);
  }
  if (operation & LOCK_EX)
    lock.l_type = F_WRLCK;
  else
    lock.l_type = F_RDLCK;
  if (operation & LOCK_NB)
    fun = F_SETLK;
  else
    fun = F_SETLKW;
  res = fcntl(fd, fun, &lock);
  if (res == -1 && (errno == EACCES || errno == EAGAIN))
    errno = EINVAL; /* EWOULDBLOCK; */
  return res;
}
