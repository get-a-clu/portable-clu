
#include <sys/types.h>

#include <errno.h>

int
ftruncate (int fd, off_t length)
{
  errno=ENOSYS;
  perror("ERROR: ftruncate not supported");

  return -1;
}

