
#include <sys/time.h>
#include <sys/timeb.h>		/* often exists */
#include <errno.h>

int setitimer(int which, const struct itimerval *value, struct itimerval *ovalue)
{
  if (which != ITIMER_REAL || ovalue || value == 0) {
    perror("ERROR: setitimer other than ITIMER_REAL not supported");
    errno = ENOSYS;
    
    return -1;
  }

  alarm(value->it_value.tv_sec);

  return 0;

}
