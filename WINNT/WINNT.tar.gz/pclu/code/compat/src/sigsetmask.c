/**
 **
 **	thanks to comp.unix.solaris	(MSch)
 **
 **/

#include <signal.h>
#undef signal

int 
sigsetmask (int mask)
{
  sigset_t oset, aset = (sigset_t)mask;

  (void)sigprocmask (SIG_SETMASK, &aset,&oset);

  return ((int) oset);
}
