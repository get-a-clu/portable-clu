#include <sys/types.h>
#include <sys/socket.h>
#include <errno.h>

int __stdcall socketpair (int *fildes)
{
  errno = ENOSYS;
  perror("ERROR: socketpair not supported");

  return -1;
}
