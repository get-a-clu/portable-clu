
#include <errno.h>

long
gethostid (void)
{

  errno=ENOSYS;
  perror("ERROR: gethostid not supported");

  return -1;
}
