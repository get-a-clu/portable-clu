#include <sys/types.h>
#include <sys/stat.h>

#include <errno.h>

int
lstat(const char *path, struct stat *sb)
{
  errno=ENOSYS;
  perror("ERROR: lstat not supported");

  return -1;
}
