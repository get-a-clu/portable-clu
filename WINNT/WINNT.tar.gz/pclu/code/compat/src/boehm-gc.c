/**
 **
 **      Title    : boehm-gc.c
 **      Created  : Mon May 24 17:05:40 1999
 **      Author   : MSch
 **      Platform : gcc
 **      Remark   : Summary of Boehm' gc functions
 **
 **/


#include "pclu_err.h"
#include "pclu_sys.h"


void 
clu_alloc (unsigned long lb, char **ans)
{
  *ans = GC_malloc (lb);
  return;
}

void
clu_alloc_atomic (unsigned long lb, char **ans)
{
  *ans = GC_malloc(lb);
  return;
}

int
GC_get_max_heap_size (void)	/* -> libasm:_get_max_heap_size */
{
  return GC_max_heapsize;
}

#if 0
void
GC_set_max_heap_size (int lb)	/* ->libasm:_set_max_heap_size */
{
  GC_max_heapsize = lb;
}
#endif

/* from gc4.10 - gc4.14 doesnt have blks_ */

static int blks_min_gc = 128;
static int blks_hard_limit = 0;

int
GC_get_min_gc (void)		/* ->libasm:_get_min_gc */
{
  return (blks_min_gc * HBLKSIZE);
}

void
GC_set_min_gc (int n)		/* ->libasm:_set_min_gc */
{
  if (n > 0)
    blks_min_gc = divHBLKSZ(n);
}

/* following comes from gc4.10 -> lp3.1b needs it */

static int addHBLK = 0xe0;
static int maskHBLK= 0x7f;

errcode
_gc_control (CLUREF add, CLUREF mask) /* ->:_gc_control */
{
  if (add.num < 0 || mask.num > add.num || mask.num < HBLKSIZE)
    signal(ERR_illegal);

  addHBLK =divHBLKSZ(add.num);
  maskHBLK=divHBLKSZ(mask.num);

  signal(ERR_ok);
}

/* There's no simple way to get the free size in gc4.14, so: */

int GC_get_free_space (void)
{
  return 0x70000000;		/* we hope this wouldn't fail anything ... */
}

#if 0
int GC_get_active_heap (void)
{

}
#endif

#if 0 /**********************************************************************/

/**
 **
 **	hacks for redirecting GC
 **
 **/

GC_PTR
GC_malloc (size_t lb) 
{
  return malloc(lb);
}

GC_PTR
GC_malloc_atomic (size_t lb) 
{
  return malloc(lb);
}

void GC_init() {}
int GC_expand_hp (size_t n) {return 1;}
void GC_free (void *p){free(p);}

int gcflag=0;
GC_word GC_gc_no=0;
void GC_gcollect (void) {GC_gc_no++;}


ptr_t
GC_generic_malloc_inner_ignore_off_page (int bytes, int kind)
{
  return (ptr_t)malloc(bytes);
}

#endif /**********************************************************************/
