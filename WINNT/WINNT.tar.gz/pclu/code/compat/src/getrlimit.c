
#include <sys/resource.h>

#include <errno.h>

int getrlimit (int resource, struct rlimit *rlp)
{

  errno=ENOSYS;
  perror("ERROR: getrlimit not supported");

  return -1;
}
