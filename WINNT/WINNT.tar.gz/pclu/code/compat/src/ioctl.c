
#include <errno.h>

int
ioctl (int d, unsigned long request, ...)
{
  errno=ENOSYS;
  perror("ERROR: ioctl not supported");

  return -1;
}
