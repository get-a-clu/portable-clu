#include <errno.h>

int
symlink (const char *name1, const char *name2)
{
  errno = ENOSYS;
  perror("ERROR: symlink not supported");

  return -1;
}
