
/**
 **
 **	thanks to comp.unix.solaris	(MSch)
 **
 **/

#include <signal.h>
#undef signal

int 
sigblock (int mask)
{
  int ret;
  sigset_t block, oblock;
  struct sigaction act, oact;


  (void)sigemptyset(&block);
  (void)sigaddset(&block,mask);

  ret = sigprocmask(SIG_BLOCK, &block, &oblock);

  if (ret < 0)
    return ret;

  return ((int) oblock);
}
