#include <errno.h>

int
fsync (int fd)
{
  errno=ENOSYS;
  perror("ERROR: fsync not supported");

  return -1;
}

