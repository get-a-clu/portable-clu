/*
  Msch borrowed from <winsock2.h>
  needed for MSC atlibasm:_host_address 
  #include <winsock2.h> would be nice
*/

#ifndef NETDB_H
#define NETDB_H

struct  hostent {
  char    *h_name;           	/* official name of host */
  char    **h_aliases;  	/* alias list */
  short   h_addrtype;           /* host address type */
  short   h_length;             /* length of address */
  char    **h_addr_list; 	/* list of addresses */
#define h_addr  h_addr_list[0]  /* address, for backward compat */
};

#define AF_INET         2               /* internetwork: UDP, TCP, etc. */

struct sockaddr {
        unsigned short sa_family;              /* address family */
        char           sa_data[14];            /* up to 14 bytes of direct address */
};

int __stdcall gethostname (char *, int);
struct hostent * __stdcall gethostbyname (char *);


int __stdcall socket (int, int, int);
int __stdcall socketpair (int *);
int __stdcall recv (int, char*, int, int);
int __stdcall recvfrom (int, char*, int, int, struct sockaddr *, int *);
int __stdcall send (int, const char *,int, int);
int __stdcall sendto (int, const char *,int, int, const struct sockaddr *, int);
int __stdcall listen (int, int);
int __stdcall accept (int, struct sockaddr *, int *);
int __stdcall bind (int, const struct sockaddr *, int);
int __stdcall connect (int, const struct sockaddr*, int);
int __stdcall shutdown (int, int);
int __stdcall getpeername (int, struct sockaddr *, int *);
int __stdcall getsockname (int, struct sockaddr *, int *);
int __stdcall getsockopt (int, int, int, char *,int*);
int __stdcall setsockopt (int, int, int, char *, int);

#endif
