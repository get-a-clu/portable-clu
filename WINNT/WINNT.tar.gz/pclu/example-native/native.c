
#include <stdio.h>

#include "pclu_err.h"
#include "pclu_sys.h"

#ifdef __GNUC__
extern int __attribute__((stdcall)) GetProcAddress(int,char *);
extern int __attribute__((stdcall)) LoadLibraryA(char *);
extern int __attribute__((stdcall)) IsBadCodePtr(void *);
#else
#include <windows.h>
#endif

char *clu_types[]={
  "", "CT_STRING",  "CT_ARRAY", "CT_AGG", "CT_VAR", "CT_PROC", "CT_STORE", "CT_TAG", "CT_REC"
};


errcode
native_call (CLUREF module, CLUREF method, CLUREF param_in, CLUREF param_out, CLUREF *ans)
{
  CLUSEQ seq;
  int i;
  int hInstance;
  int __attribute__((stdcall)) (*p)();
  unsigned long *tags;
  int count;

  if (param_in.cell->typ.val != CT_VAR) {
    signal(ERR_not_possible);
  }

  hInstance = (long *)LoadLibraryA(module.str->data);
  if (hInstance == NULL) {
    signal(ERR_not_possible);
  }

  seq = (CLUSEQ)param_in.cell->value;
  count = seq->size;
  printf("%d parameters:\n", count);

  tags=(int*)malloc(count*sizeof(unsigned long));
  if (tags == NULL) {
    signal(ERR_not_possible);
  }
  memset(tags,0,sizeof(seq->size));

  for (i=0; i < seq->size; i++) {
    if (IsBadCodePtr((void*)seq->data[i])) {
      printf("[%d] : VALUE  %d\n",i,seq->data[i]);
      tags[i]=seq->data[i];
    }
    else {
      printf("[%d] : CLUREF %s\n",i,clu_types[((CLUREF)seq->data[i]).store->typ.val]);
      tags[i]=(unsigned long)((CLUSTRING)seq->data[i])->data;
    }
  }

  p = GetProcAddress(hInstance,method.str->data);
  if (p == NULL) {
    free(tags);
    signal(ERR_not_possible);
  }
				/* marshalling - not very poartable. */
  if (count) {
      asm ("	movl %0, %%edx;
                movl %1, %%ecx;
          1:	movl (%%edx,%%ecx,4), %%eax;
                pushl %%eax;
                decl %%ecx;
                jns 1b;"
	 : /* no output */
	 : "g"(tags), "g"(count)
	 : "%eax", "%ecx", "%edx");
  }

  ans->num = p();

  free(tags);

  signal(ERR_ok);
}


