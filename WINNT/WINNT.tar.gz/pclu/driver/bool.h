#ifndef _BOOL_H
#define _BOOL_H

typedef int bool;

#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE 1
#endif

#endif /* _BOOL_H */
