#ifndef lint
static char rcsid[] = "$Header: setjmp_test.c,v 1.2 91/05/06 12:26:01 dcurtis Exp $";
#endif
/* $Log:	setjmp_test.c,v $
 * Revision 1.2  91/05/06  12:26:01  dcurtis
 * *** empty log message ***
 * 
 * Revision 1.1  91/02/04  16:21:41  mtv
 * Initial revision
 * 
 */

/* Check whether setjmp actually saves registers in jmp_buf. */
/* If it doesn't, the generic mark_regs code won't work.     */
#include <stdio.h>
#include <setjmp.h>
#include "gc.h"
main()
{
	jmp_buf b;
	register int x = 1;
	static int y = 0;

	setjmp(b);
	if (y == 1) {
	    if (x == 2) {
		printf("Generic mark_regs code wont work\n");
#		ifdef SPARC
		    printf("Assembly code supplied\n");
#		else
		    printf("Need assembly code\n");
#		endif
	    } else if (x == 1) {
		printf("Generic mark_regs code may work\n");
	    } else {
		printf("Very strange setjmp implementation\n");
	    }
	}
	y++;
	x = 2;
	if (y == 1) longjmp(b, 0);
	return(0);
}

int g(x)
int x;
{
	return(x);
}
