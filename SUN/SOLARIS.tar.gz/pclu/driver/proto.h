#ifndef _PROTO_H
#define _PROTO_H

#ifdef __STDC__
#define ARGS(x) x
#else
#define ARGS(x) ()
#endif

#endif /* _PROTO_H */
