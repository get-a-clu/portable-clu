/*						*/
/*						*/
/*		IMPLEMENTATION OF		*/
/*	   	   unix_cmd			*/
/*						*/

#include "pclu_err.h"
#include "pclu_sys.h"
#include <sys/wait.h>

#if !defined(LINUX) && !defined(SPARC)
extern char *system();
#endif

errcode unix_cmd(input)
CLUREF input;
{
char *result;
CLUREF temp_str, n, num, size;
errcode err;

	result = system((char*)input.vec->data); 
/*	printf("err = %X, %X %X %X\n", err, WTERMSIG(err), 
		WEXITSTATUS(err), WSTOPSIG(err)); */
	if (result == NULL) signal(ERR_ok);
	err = stringOPcons("call to system failed: ", CLU_1, CLU_23, 
			   &temp_str);
	n.num = (int)result;
	err = intOPunparse(n, &num);
	err = stringOPconcat(temp_str, num, &temp_str);
	elist[0] = temp_str;
	signal(ERR_failure);
	}
