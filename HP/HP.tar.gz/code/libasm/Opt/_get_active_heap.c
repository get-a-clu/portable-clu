
/* Copyright Massachusetts Institute of Technology 1993 */

#include "pclu_err.h"
#include "pclu_sys.h"

errcode _get_active_heap(ans)
CLUREF *ans;
{
	ans->num = blks_active * HBLKSIZE;
	signal(ERR_ok);
	}
