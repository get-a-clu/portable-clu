
/* Copyright Massachusetts Institute of Technology 1993 */

#include "pclu_err.h"
#include "pclu_sys.h"

errcode _str_lit_cat(ans)
CLUREF *ans;
{
#if defined(ALPHA) || defined(HP_PA)
        ans->tf = TRUE;
#else
        ans->tf = FALSE;
#endif
        signal(ERR_ok);
        }
